package com.example.Insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Insurance.Response.Response;
import com.example.Insurance.Service.InsurancePolicyService;
import com.example.Insurance.Entity.InsurancePolicy;

@RestController
@RequestMapping("/api")
public class InsurancePolicyController {
     @Autowired
     private InsurancePolicyService insuranceService;
     
     @PostMapping("/saveInsurancePolicy")
     public Response<InsurancePolicy> insertInsurancePolicy(@RequestBody InsurancePolicy insurancePolicy){
    	 return insuranceService.insertInurancePolicy(insurancePolicy);
     }
     @GetMapping("/getByInsurancePolicyId/{insurancePolicyId}")
     public Response<InsurancePolicy> getByInsurancePolicyId(@PathVariable int insurancePolicyId){
    	 return insuranceService.getByInsurancePolicyId(insurancePolicyId);
     }
     @DeleteMapping("/deleteInsurancePolicy/{policyId}")
     public Response<InsurancePolicy> deleteInsurancePolicy(@PathVariable int policyId){
    	 return insuranceService.deleteInusrancePolicy(policyId);
     }
     @GetMapping("/displayAllPolicy")
     public Response<List<InsurancePolicy>> displayAllPolicy(){
    	 return insuranceService.displayAllInsurancePolicy();
     }
}
