package com.example.Insurance.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "insurancePolicy")
public class InsurancePolicy {
	
	   @Id
	   //@GeneratedValue (strategy = GenerationType.AUTO)
	   @Column(name="policyId")
	   private int insurancePolicyId; 
	   
	   @Column(name="policyNumber")
	   private String insurancePolicyNumber;
	   
	   @Column(name="policyType")
	   private String insurancePolicyType;
	   
	   @Column(name="policyCoverageAmount")
	   private long insurancePolicyCoverageAmount;
	   
	   @Column(name="policyPremium")
	   private String insurancePolicyPremium;
	   
	   @Column(name="policyStartDate")
	   private String insurancePolicyStartDate;
	   
	   @Column(name="policyEndDate")
	   private String insurancePolicyEndDate;
	   

}
