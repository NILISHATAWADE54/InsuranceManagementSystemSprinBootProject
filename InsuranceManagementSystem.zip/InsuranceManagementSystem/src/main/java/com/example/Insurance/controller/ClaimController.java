package com.example.Insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Insurance.Response.Response;
import com.example.Insurance.Service.ClaimService;
import com.example.Insurance.Entity.Claim;

@RestController
@RequestMapping("/api")
public class ClaimController {
	@Autowired
	private ClaimService claimService;
	
	@PostMapping("/saveClaim/{policyId}")
	public Response<Claim> saveClaim(@RequestBody Claim claim, @PathVariable int policyId) {
	    return claimService.insertClaim(claim, policyId);
	}

	@GetMapping("/getByClaimId/{claimId}")
	public Response<Claim> getByClaimId(@PathVariable int claimId) {
		return claimService.getByClaimId(claimId);
	}
	@DeleteMapping("/deleteClaim/{claimId}")
	public Response<Claim> deleteClaim(@PathVariable int claimId){
		return claimService.deleteClaim(claimId);
	}
	@PutMapping("/updateClaim/{claimId}")
	public Response<Claim> updateClaim(@RequestBody Claim claim){
		return claimService.updateClaim(claim);
	}
	@GetMapping("/displayAllClaim")
	public Response<List<Claim>>displayAllCliam(){
		return claimService.displayAllClaim();
	}
}
