package com.example.Insurance.Service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.Insurance.Dao.ClaimDao;
import com.example.Insurance.Dao.InsurancePolicyDao;
import com.example.Insurance.Response.Response;
import com.example.Insurance.Entity.Claim;
import com.example.Insurance.Entity.InsurancePolicy;

@Service
public class ClaimService {
	@Autowired
	private InsurancePolicyDao insurancePolicyDao;
	
	@Autowired
	private ClaimDao claimDao;
	
	@Autowired
	private Response<Claim> claimResponse;
	
	@Autowired
	private Response<List<Claim>> findAllResponse;
	
	public Response<Claim> insertClaim(Claim claim,int policyId){
		InsurancePolicy insurancePolicy=insurancePolicyDao.getByInsurancePolicyId(policyId);
		if(Objects.isNull(insurancePolicy)){
			claimResponse.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			claimResponse.setMsg("Not Claimed yet!");
			claimResponse.setData(null);
		}
		else{
			claim.setInsurancePolicy(insurancePolicy);
			claimDao.insertClaim(claim);
			claimResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			claimResponse.setMsg("Claimed Successfully Done!");
			claimResponse.setData(claim);
		}
		return claimResponse;
	}
		public Response<Claim> getByClaimId(int claimId){
			Claim claim = claimDao.getByClaimId(claimId);
			if(Objects.isNull(claim)) {
				throw new RuntimeException("Claim Details Not Found");
			}
			claimResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			claimResponse.setMsg("Claimed exist!");
			claimResponse.setData(claim);
			
			return claimResponse;
		}
		public Response<Claim> deleteClaim(int claimId){
			Claim claim = claimDao.deleteClaim(claimId);
			if(Objects.isNull(claim)) {
				throw new RuntimeException("ClaimId Not Found");
			}
			claimResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			claimResponse.setMsg("Claimed exist!");
			claimResponse.setData(claim);
			
			return claimResponse;
		}
		
		public Response<Claim>updateClaim(Claim claim){
			Claim updateClaim=claimDao.deleteClaim(claim.getClaimId());
			if(Objects.isNull(updateClaim)) {
				throw new RuntimeException("Claim Details Not Found!");
			}
			updateClaim.setClaimNumber(claim.getClaimNumber());
			updateClaim.setClaimDate(claim.getClaimDate());
			updateClaim.setClaimDescription(claim.getClaimDescription());
			updateClaim.setClaimStatus(claim.getClaimStatus());
			claimDao.updateClaim(updateClaim);
			
			claimResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			claimResponse.setMsg("Claim Updated Successfully!");
			claimResponse.setData(claim);
			return claimResponse;
		}
		
		public Response<List<Claim>>displayAllClaim(){
			List<Claim> Claims =claimDao.displayAllClaim();
			if(Objects.isNull(Claims)) {
				findAllResponse.setStatusCode(HttpStatus.NOT_FOUND.value());
				findAllResponse.setMsg("Claim Detais Are Not Available!");
				findAllResponse.setData(null);
				
			}
			else {
				findAllResponse.setStatusCode(HttpStatus.FOUND.value());
				findAllResponse.setMsg("Claim Detais Are  Available!");
				findAllResponse.setData(Claims);
			}
			return findAllResponse;
		}
}
