package com.example.Insurance.Response;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class Response<T> {
	
        private int StatusCode;
        
        private String Msg;
        
        private T Data;

		public int getStatusCode() {
			return StatusCode;
		}

		public void setStatusCode(int statusCode) {
			StatusCode = statusCode;
		}

		public String getMsg() {
			return Msg;
		}

		public void setMsg(String msg) {
			Msg = msg;
		}

		public T getData() {
			return Data;
		}

		public void setData(T data) {
			Data = data;
		}
        
        
        
}
