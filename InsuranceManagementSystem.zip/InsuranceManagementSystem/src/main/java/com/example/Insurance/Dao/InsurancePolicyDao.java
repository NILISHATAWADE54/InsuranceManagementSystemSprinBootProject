package com.example.Insurance.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.Insurance.Repository.InsurancePolicyRepository;
import com.example.Insurance.Entity.InsurancePolicy;



@Repository
public class InsurancePolicyDao {
	 @Autowired
     private InsurancePolicyRepository insuranceRepository;
     
     public InsurancePolicy insertInsurancePolicy(InsurancePolicy insurancePolicy) {
  	   return insuranceRepository.save(insurancePolicy);
     }
     
     public InsurancePolicy getByInsurancePolicyId(int insurancePolicyId) {
  	   Optional<InsurancePolicy>optional=insuranceRepository.findById(insurancePolicyId);
  			   if(optional.isPresent()) {
  				   return optional.get();
  			   }
  	   return null;
     }
     public InsurancePolicy deleteInsurancePolicyId(int inusrancePolicyId) {
  	   Optional<InsurancePolicy>optional=insuranceRepository.findById(inusrancePolicyId);
  			   if(optional.isPresent()) {
  				   return optional.get();
  			   }
  	   return null;
     }
     
     
     public List<InsurancePolicy>displayAllInsurancePolicy(){
  	   return insuranceRepository.findAll();
     }
}
