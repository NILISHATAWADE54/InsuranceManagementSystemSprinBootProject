package com.example.Insurance.Entity;

import jakarta.persistence.*;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Claim")
public class Claim {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="claimId")
    private int claimId;
    
    @Column(name="claimNumber")
    private long claimNumber;
     
    @Column(name="claimDate")
    private String claimDate;
    
    @Column(name="claimDescription")
    private String claimDescription;
    
    @Column(name="claimStatus")
    private String claimStatus;
    
    @Column(name="claimAmount")
    private int claimAmount;
    
    @OneToOne
    @JoinColumn(name="policyId")
    private InsurancePolicy insurancePolicy;
}
