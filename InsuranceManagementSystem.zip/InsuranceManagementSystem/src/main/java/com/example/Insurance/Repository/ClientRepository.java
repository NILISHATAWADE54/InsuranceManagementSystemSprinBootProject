package com.example.Insurance.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Insurance.Entity.Client;

public interface ClientRepository extends JpaRepository<Client,Integer> {

}
