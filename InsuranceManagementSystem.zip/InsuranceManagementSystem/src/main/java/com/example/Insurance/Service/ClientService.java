package com.example.Insurance.Service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.Insurance.Dao.ClientDao;
import com.example.Insurance.Dao.InsurancePolicyDao;
import com.example.Insurance.Response.Response;
import com.example.Insurance.Entity.Client;
import com.example.Insurance.Entity.InsurancePolicy;

@Service
public class ClientService {
	@Autowired
	private InsurancePolicyDao insurancePolicyDao;
	
	@Autowired
	private ClientDao clientDao;
	
	@Autowired
	private Response<Client> clientResponse;
	
	@Autowired
	private Response<List<Client>> findAllResponse;
	
	public Response<Client> insertClaim(Client client,int policyId){
		InsurancePolicy insurancePolicy=insurancePolicyDao.getByInsurancePolicyId(policyId);
		if(Objects.isNull(insurancePolicy)){
			clientResponse.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			clientResponse.setMsg("Not Client yet!");
			clientResponse.setData(null);
		}
		else{
			client.setInsurancePolicy(insurancePolicy);
			clientDao.insertClient(client);
			clientResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			clientResponse.setMsg("Claimed Successfully Done!");
			clientResponse.setData(client);
		}
		return clientResponse;
	}
		public Response<Client> getByClientId(int clientId){
			Client claim = clientDao.getByClientId(clientId);
			if(Objects.isNull(claim)) {
				throw new RuntimeException("Claim Details Not Found");
			}
			clientResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			clientResponse.setMsg("Claimed exist!");
			clientResponse.setData(claim);
			
			return clientResponse;
		}
		public Response<Client> deleteClient(int claimId){
			Client client = clientDao.deleteClientId(claimId);
			if(Objects.isNull(client)) {
				throw new RuntimeException("ClaimId Not Found");
			}
			clientResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			clientResponse.setMsg("Client exist!");
			clientResponse.setData(client);
			
			return clientResponse;
		}
		
		public Response<Client>updateClient(Client client){
			Client updateClient=clientDao.deleteClientId(client.getClientId());
			if(Objects.isNull(updateClient(client))) {
				throw new RuntimeException("Client Details Not Found!");
			}
			updateClient.setClientName(client.getClientName());
			updateClient.setClientDateOfBirth(client.getClientDateOfBirth());
			updateClient.setClientAddress(client.getClientAddress());
			updateClient.setClientContactInformation(client.getClientContactInformation());
			clientDao.updateClient(updateClient);
			
			clientResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			clientResponse.setMsg("Client Updated Successfully!");
			clientResponse.setData(client);
			return clientResponse;
		}
		
		public Response<List<Client>>displayAllClient(){
			List<Client> Claims =clientDao.displayAllClient();
			if(Objects.isNull(Claims)) {
				findAllResponse.setStatusCode(HttpStatus.NOT_FOUND.value());
				findAllResponse.setMsg("Client Detais Are Not Available!");
				findAllResponse.setData(null);
				
			}
			else {
				findAllResponse.setStatusCode(HttpStatus.FOUND.value());
				findAllResponse.setMsg("Client Detais Are  Available!");
				findAllResponse.setData(Claims);
			}
			return findAllResponse;
		}
}
