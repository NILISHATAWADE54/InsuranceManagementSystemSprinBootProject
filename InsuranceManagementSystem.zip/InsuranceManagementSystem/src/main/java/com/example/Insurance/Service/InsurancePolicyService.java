package com.example.Insurance.Service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.stereotype.Service;


import com.example.Insurance.Dao.InsurancePolicyDao;
import com.example.Insurance.Response.Response;
import com.example.Insurance.Entity.InsurancePolicy;

@Service
public class InsurancePolicyService {
	@Autowired
	private InsurancePolicyDao insurancePolicyDao;
	
	@Autowired
	private Response<InsurancePolicy> insurancePolicyResponse;
	
	@Autowired
	private Response<List<InsurancePolicy>> findAllResponse;
	
	public Response<InsurancePolicy> insertInurancePolicy(InsurancePolicy insurancePolicy){
		 insurancePolicy=insurancePolicyDao.insertInsurancePolicy(insurancePolicy);
		if(Objects.isNull(insurancePolicy)){
			insurancePolicyResponse.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			insurancePolicyResponse.setMsg("Not InsurancePolicy yet!");
			insurancePolicyResponse.setData(null);
		}
		else{
			insurancePolicyResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			insurancePolicyResponse.setMsg("InsurancePolicy Successfully Done!");
			insurancePolicyResponse.setData(insurancePolicy);
		}
		return insurancePolicyResponse;
	}
		public Response<InsurancePolicy> getByInsurancePolicyId(int policyId){
			InsurancePolicy insurance =insurancePolicyDao.getByInsurancePolicyId(policyId);
			if(Objects.isNull(insurance)) {
				throw new RuntimeException("InsurancePolicy Details Not Found");
			}
			insurancePolicyResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			insurancePolicyResponse.setMsg("InsurancePolicy exist!");
			insurancePolicyResponse.setData(insurance);
			
			return insurancePolicyResponse;
		}
		public Response<InsurancePolicy> deleteInusrancePolicy(int claimId){
			InsurancePolicy insurance = insurancePolicyDao.deleteInsurancePolicyId(claimId);
			if(Objects.isNull(insurance)) {
				throw new RuntimeException("InsurancePolicyId Not Found");
			}
			insurancePolicyResponse.setStatusCode(HttpStatus.ACCEPTED.value());
			insurancePolicyResponse.setMsg("InsurancePolicy exist!");
			insurancePolicyResponse.setData(insurance);
			
			return insurancePolicyResponse;
		}
		
		public Response<List<InsurancePolicy>>displayAllInsurancePolicy(){
			List<InsurancePolicy> Claims =insurancePolicyDao.displayAllInsurancePolicy();
			if(Objects.isNull(Claims)) {
				findAllResponse.setStatusCode(HttpStatus.NOT_FOUND.value());
				findAllResponse.setMsg("Insurance Details Are Not Available");
				findAllResponse.setData(null);
				
			}
			else {
				findAllResponse.setStatusCode(HttpStatus.FOUND.value());
				findAllResponse.setMsg("insuranc Deatails Are Available:");
				findAllResponse.setData(Claims);
			}
			return findAllResponse;
		}
}

