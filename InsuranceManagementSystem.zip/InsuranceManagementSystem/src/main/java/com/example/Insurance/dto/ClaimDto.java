package com.example.Insurance.dto;

import jakarta.persistence.GeneratedValue;

import com.example.Insurance.Entity.InsurancePolicy;

import jakarta.persistence.Column;
import jakarta.persistence.GenerationType;
import jakarta.persistence. Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;



public class ClaimDto {
     @Id
     @GeneratedValue(strategy=GenerationType.AUTO)
     @Column(name="claimId")
     private int claimId;
     
     @Column(name="claimNumber")
     private long claimNumber;
      
     @Column(name="claimDate")
     private int claimDate;
     
     @Column(name="claimDescription")
     private String claimDescription;
     
     @Column(name="claimStatus")
     private int claimStatus;
     @Column(name="claimAmount")
     private int claimAmount;
     
     @OneToOne
     @JoinColumn(name="policyId")
     private InsurancePolicy insurancePolicy;
	
     
}
