package com.example.Insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Insurance.Response.Response;
import com.example.Insurance.Service.ClientService;
import com.example.Insurance.Entity.Client;

@RestController
@RequestMapping("/api")
public class ClientController {
	@Autowired
	private ClientService clientService;
	
	@PostMapping("/saveClient/{policyId}")
	public Response<Client> saveClient(@RequestBody Client client,@PathVariable int policyId){
	 return clientService.insertClaim(client, policyId);
	}
	@GetMapping("/getByClientId/{clientId}")
	public Response<Client> getByClientId(@PathVariable int clientId) {
		return clientService.getByClientId(clientId);
	}
	@DeleteMapping("/deleteClient/{clientId}")
	public Response<Client> deleteClient(@PathVariable int clientId){
		return clientService.deleteClient(clientId);
	}
	@PutMapping("/updateClient/{clientId}")
	public Response<Client> updateClient(@RequestBody Client client){
		return clientService.updateClient(client);
	}
	@GetMapping("/displayAllClient")
	public Response<List<Client>>displayAllClient(){
		return clientService.displayAllClient();
	}

}
