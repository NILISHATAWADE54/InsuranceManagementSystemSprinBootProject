package com.example.Insurance.Entity;

import com.example.Insurance.Entity.InsurancePolicy;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="Client")
@Getter
@Setter
public class Client {
	@Id
	@Column(name="ClientId")
	private int clientId;
	
	@Column(name="ClientName")
	private String clientName;
	
	@Column(name="ClientDateOfBirth")
	private String clientDateOfBirth;
	
	@Column(name="ClientAddress")
	private String clientAddress;
	
	@Column(name="ClientContactInformation")
	private String clientContactInformation;
	
	@ManyToOne
	@JoinColumn(name="policyId")
	private InsurancePolicy insurancePolicy;
}
