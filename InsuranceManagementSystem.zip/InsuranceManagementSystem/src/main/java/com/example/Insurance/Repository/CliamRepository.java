package com.example.Insurance.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Insurance.Entity.Claim;

public interface CliamRepository extends JpaRepository<Claim,Integer> {

}
