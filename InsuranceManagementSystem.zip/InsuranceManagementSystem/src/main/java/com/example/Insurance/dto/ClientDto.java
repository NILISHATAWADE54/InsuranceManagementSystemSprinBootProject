package com.example.Insurance.dto;

import com.example.Insurance.Entity.InsurancePolicy;

import jakarta.persistence.Column;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence. Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


public class ClientDto {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ClientId")
	private int clientId;
	
	@Column(name="ClienName")
	private String clientName;
	
	@Column(name="ClietDateOfBirth")
	private String clientDateOfBirth;
	
	@Column(name="ClientAddress")
	private String clientAddress;
	
	@Column(name="ClientContactInformation")
	private int clientContactInformation;
	
	@ManyToOne
	@JoinColumn(name="policyId")
	private InsurancePolicy insurancePolicy;
	
	

}
